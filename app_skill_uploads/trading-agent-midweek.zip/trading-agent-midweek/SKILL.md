---
name: trading-agent-midweek
description: Wednesday validator for the autonomous trading agent. Reviews open positions for thesis integrity and EMA signal degradation, decides hold/cut/redeploy, and tracks the T+1 settlement schedule. Use only when running this agent's midweek review.
---

# skill_3_midweek — Wednesday validator (Phase C)

Review all open positions every Wednesday and decide hold vs. cut vs. redeploy.

## For each open position
- Is the thesis still intact?
- Has news or Reddit sentiment shifted against it?
- Is the EMA signal still holding (is the 55/red still the lowest line, or are
  the lines starting to converge — an early warning the trend is rolling over)?
- Are the original entry/exit targets still realistic given how price has moved?
- Should the position be cut early (thesis broken, or the signal is degrading)
  rather than waiting for the full SELL crossover?

## Cash & settlement
- What cash is settling and when (T+1)? State what is deployable now vs. later
  this week so research doesn't plan around money that isn't free yet.

## Redeploy
- Is there a better opportunity to redeploy into once cash settles?

## Output
Write `research/midweek_review_YYYY-MM-DD.md`: a per-position verdict (hold /
cut / trim) with reasoning and the current EMA state, the settlement schedule,
and any redeployment candidate. Cuts that meet the SELL criteria are executed via
the Robinhood MCP; otherwise flag them for the next execution cycle.
