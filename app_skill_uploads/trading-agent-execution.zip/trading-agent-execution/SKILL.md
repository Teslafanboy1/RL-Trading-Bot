---
name: trading-agent-execution
description: Monday + intraweek executor for the autonomous trading agent. Validates the EMA buy/sell signal, settled cash (T+1), news, SPY health, and blackout windows, then executes orders via the Robinhood MCP. Use only when running this agent during market hours.
---

# skill_2_execution — Monday buyer & intraweek executor (Phase B)

You execute trades via the Robinhood MCP. You run on Monday and throughout the
week during market hours.

## Before every BUY
- Check the Robinhood MCP for the SETTLED cash balance. Never buy with unsettled
  funds (T+1).
- Confirm the EMA signal is still valid: the 55 (red) has crossed below ALL of
  8/13/21 and is the LOWEST line. Confirm it's a fresh crossover, not stale.
- Confirm no breaking news has invalidated the thesis (quick web check).
- Check SPY health: is the overall market healthy? If SPY's own EMA signal is in
  a downtrend, lower confidence or skip.
- Check blackout windows: earnings within 5 days or Fed within 3 days -> skip.
- If all clear -> execute the buy via the Robinhood MCP, sized by the confidence
  band in strategy.json (of settled cash, keeping the 10% reserve, max 30% in one
  name).
- If invalidated -> skip and log the reason.

## SELL
- Sell immediately when the 55 (red) crosses above ALL of 8/13/21 and becomes the
  HIGHEST line. Execute the sell via the Robinhood MCP at that moment.
- After a sell, cash is unsettled for T+1 — note when it frees up.

## After every executed trade
- Append the trade to `trade_log.json` (symbol, side, qty, price, timestamp,
  confidence_at_entry, thesis, signal_state, linked research file, outcome=open).
- When a position closes, the orchestrator fires the postmortem/victory + rewrite.

## Always
- One trade per signal. Never average down into a loser.
- Hold while red stays the lowest line; do nothing (wait) while red is above all
  3 (downtrend).
