---
name: trading-agent-postmortem
description: Loss analyst for the autonomous trading agent. Fires after every losing trade: diagnoses root cause, identifies the misleading source, updates source performance, and proposes preventive rules. Use only when analyzing a losing trade for this agent.
---

# skill_4_postmortem — Loss analyst (Phase D)

Fires after every LOSING trade closes. Write `postmortems/postmortem_NNN.md`.
Weight the analysis deeper for high-confidence losses — those matter most,
because a 90-confidence loss means something in the model is wrong.

## Diagnose
- What went wrong? What was the thesis and confidence at entry vs. what happened?
- Which source misled us — news, Reddit/social, fundamentals, or macro?
- Was the confidence score too high for the evidence?
- Was the EMA signal weak or false (lines knotted/whipsaw) rather than a clean
  55-crosses-all-3 crossover?
- Was the entry timing wrong (chased after the move)?
- Was it a blackout-window miss (earnings/Fed) we should have caught?

## Decide
- What rule do we ADD to prevent this from repeating?
- What do we REDUCE or ELIMINATE (a source, a sector, a sizing choice)?

## Update
- Update the misleading source's win/loss record in
  `strategy.json.source_performance` (losses +1, recompute accuracy).
- Record the per-source outcome for confidence calibration.
- Propose preventive rules to skill_5, but do NOT change a core buy/sell rule on
  one loss — skill_5 requires 3+ similar losses before touching a core rule.
