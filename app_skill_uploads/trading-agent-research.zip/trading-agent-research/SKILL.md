---
name: trading-agent-research
description: Weekend research scanner for the autonomous trading agent. Scans news/Reddit/RSS/MCP/macro, scores candidates 0-100, sets entry/exit targets, allocates capital by confidence band, and writes weekend_picks. Use only when running this agent's weekend research phase.
---

# skill_1_research — Weekend scanner (Phase A)

You find the best stock candidate for the coming week and size it. You learn from
past postmortems and victories which sources and signals to trust most.

## Process
1. Pull current settled cash + open positions from the Robinhood MCP.
2. Scan ALL sources, weighting by what has actually worked (read
   `source_performance` in strategy.json, not just the static `source_weights`):
   - News (web search financial news)
   - Reddit (WSB, investing, stocks)
   - RSS financial feeds (Bloomberg / Reuters / MarketWatch)
   - Fundamentals (Robinhood MCP stock data)
   - Macro (Fed calendar + earnings calendar)
3. For each candidate, evaluate the EMA signal: is the 55 (red) crossing below
   all of 8/13/21 to become the LOWEST line (BUY), or already there (hold-able)?
   Only candidates at/entering the BUY crossover qualify; the rest are watchlist.
4. Score each candidate with a confidence score 0-100 from source agreement and
   signal strength.
5. Set an entry target price and an exit target price.
6. Check blackout windows: earnings within 5 days or Fed within 3 days -> skip.
7. Allocate capital by confidence band (of available settled capital):
   - 90-100 -> 30%   - 75-89 -> 20%   - 60-74 -> 15%   - below 60 -> skip
   - Always keep 10% cash reserve. Never plan to buy with unsettled funds.

## Output
Write `research/weekend_picks_YYYY-MM-DD.md`:
- A ranked list of picks with confidence scores, entry/exit targets, dollar
  allocation, and full reasoning (which sources drove it, the EMA state, and the
  one thing that would invalidate the thesis).
- An explicit settled-cash line and "deploying $X, holding $Y."
- If nothing qualifies, say so and list the watchlist with the trigger level.
