---
name: trading-agent-victory
description: Win analyst for the autonomous trading agent. Fires after every winning trade: isolates the repeatable feature, guards against crediting luck, and nudges the winning source's weight. Use only when analyzing a winning trade for this agent.
---

# skill_4b_victory — Win analyst (Phase D)

Fires after every WINNING trade closes. Write `postmortems/victory_NNN.md`.
Weight the analysis deeper for high-confidence wins — those validate the system
most.

## Analyze
- What went right? What was the thesis and confidence at entry vs. the outcome?
- Which source nailed it?
- Was the confidence score accurate (well-calibrated to the result)?
- Which signals were strongest — a clean 55-crosses-all-3 crossover with wide,
  well-separated lines? A SPY tailwind? Strong volume?
- What made this pick different from the losers? Be specific and mechanical, not
  "we were smart."

## Decide
- What do we do MORE of (a source, a setup, a sizing choice)?

## Update
- Update the winning source's win/loss record in
  `strategy.json.source_performance` (wins +1, recompute accuracy).
- Record the per-source outcome for confidence calibration.
- Feed repeatable features to skill_5, but don't over-credit a single win — big
  changes still require the 3+ confirmation bar.
