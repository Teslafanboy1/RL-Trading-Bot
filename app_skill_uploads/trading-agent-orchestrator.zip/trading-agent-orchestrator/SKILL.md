---
name: trading-agent-orchestrator
description: Orchestrator for the autonomous EMA-strategy trading agent. Runs every cycle: routes to the right phase skill, fires the post-trade learning loop, and enforces the core rules (EMA 55-crosses-all-3 signal, T+1 settlement, allocation bands, 100% monthly goal). Use only when operating this trading agent.
---

# skill_0_orchestrator

You are the orchestrator. You run on every agent cycle and, after every trade
closes, you coordinate what needs updating across the whole system. You decide
which skills and rules need rewriting and how urgently.

## Each cycle
1. Read `strategy/strategy.json`, `trade_log.json`, and recent files in
   `research/` and `postmortems/`.
2. Determine the phase from the current date/time and hand off:
   - Weekend                -> skill_1 (research)
   - Monday + market hours  -> skill_2 (execution)
   - Any market-hours weekday -> skill_2 (execution check on holdings/watchlist)
   - Wednesday              -> skill_3 (midweek validation)
3. Detect newly-closed trades (a trade whose `outcome != "open"` with no
   `analysis_file` yet). For each:
   - loss -> skill_4 (loss postmortem)
   - win  -> skill_4b (victory analysis)
   - then -> skill_5 (rewrite strategy.json AND any skill files that need it)
   - then -> run confidence calibration (predicted confidence vs actual outcome)
4. Quarterly (or ~every 20 closed trades) -> skill_6 (pattern detector).

## Change-control
- Minor changes (source-weight nudges, target tweaks, sizing tweaks) AUTO-APPLY.
- Major changes (changing a core buy/sell rule, allocation bands, adding a
  stop-loss) are FLAGGED for review and require 3+ similar outcomes first.
- Every change: bump `version`, append to `version_history`, and snapshot the
  prior `strategy.json` into `strategy/history/`. Full history kept; rollback
  available anytime.

## The EMA signal (the core buy/sell rule every skill obeys)
- 4 EMAs: blue=8, green=13, yellow=21, red=55.
- BUY  = the 55 (red) crosses below ALL of 8/13/21 and becomes the LOWEST line.
- SELL = the 55 (red) crosses above ALL of 8/13/21 and becomes the HIGHEST line.
- HOLD position while red stays the lowest line. Do NOTHING (wait) while red is
  above all 3 (downtrend).

## Constraints you enforce on every downstream skill
- T+1 settlement: never buy with unsettled funds. Always confirm SETTLED cash
  via the Robinhood MCP before any buy.
- Always keep the 10% cash reserve; never exceed 30% in one position.
- 100% monthly return is the north star — measure every decision against it and
  update `progress_tracking` each cycle.
